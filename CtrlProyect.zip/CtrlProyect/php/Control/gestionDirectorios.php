<?php
/**
* 	Clase encargada de la gestion directa del Directorio Proyectos/ donde se guardan los proyectos.
*	esta Clase cumple funciones de Crear, eliminar, Directorios.
*/
class gestionDirectorios{
	private $direcion="../../proyectos/";
	private $obj;


	protected function leerProyectos(){
		$this -> obj= dir($this->direcion);	
		echo '
		<select title="Proyectos Registrados en el Directorio Proyectos/" class="form-control"  name="" id="proyectos2">
				<option value="no">Selecciona Tu Proyectos...</option>
		';
		while ( $elemento = $this ->obj-> read()) {
			echo '		
				<option value="'.$elemento.'">'.$elemento.'</option>
			';		
		}	
		echo '		
		 </select>
		'; 
	}
	 function creaDirectoriosWeb($path){
		mkdir($this->direcion.$path,0777);
	}
	 function buscarDirectorio($ruta){
		if(is_dir($this-> direcion.$ruta)){
			echo '
						</br>
						<div class="alert alert-dismissible fade in" role="alert">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">	
									<span aria-hidden="true">
										&times;
									</span>
								</button>
								<strong class="text-center" >
									Lo Sentimos ya se encuentra Registrado un proyecto con este "Nombre".
								</strong>
								<input id="inicio" value="0" type="text" style="display:none"></input>
						</div>
			';
		}
		else{
			echo '
						<div class="alert alert-dismissible fade in" role="alert">
								<button type="button"  class="close" data-dismiss="alert" aria-label="Close">
								 	<span aria-hidden="true">
								 		&times;
								 	</span> 
								</button>
								<strong class="text-center" >
								 	Datos Validados con exito.</br>Pulse Click sobre Guardar
								</strong>
								<input id="inicio" value="1" type="text" style="display:none" ></input>
						</div>
			';
		}
	}


	 function buscar($nombre){
		$res;
		if(is_dir($this-> direcion.$nombre)){
			$res=true;
		}
		else{
			$res=false;
		}
		return ($res);
	}
}
?>