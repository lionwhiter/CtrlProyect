<?php
include_once("../Vista/Operaciones.php");
class Operacion extends Operaciones{

	private $op =null;
	
	public function __construct(){
		$this->op=$_GET['x'];
	 	$this->proceso();
	}
	public function __destruct(){
	}
	
	private function proceso(){
		if (isset($this->op) ){
				switch($this->op){
					case 1:
						$this ->formuIngresar();
					break;
					case 2:
						$this ->formuActualizar();
					break;
					case 3:
						$this ->formuEliminar();
					break;	
					case 4:
						$this-> Actualizar_EliminarProyct("Actualizar");
					break;	
					case 5:
						$this-> Actualizar_EliminarProyct("Eliminar");
					break;	
					default:
						echo'
							Error  inesperado Comuniquese con su administrador
						';
					break;
				}
		}
	}
	
}
	$ejecucion= new Operacion(); 
?>