<?php
class comunicacionDB{
     private $conexion;
    public function open($db){
        $this -> conexion= new mysqli("localhost","root","",$db) or die ("Error en la Conexion con el SELVIDOR");
			if ($this->conexion->connect_error){
				echo 'Fallo la conecion con la MYSQL: '.$this->conexion->connect_error;
			}
    }
		public function __destruct(){	
		}
    //cerrar la base de datos:
    protected  function close(){
    	$this -> conexion->close(); 
    }
	protected  function liberar($ml){
	   $ml->close();
	}
    //permite realizar registro dentro de la base de datos:
    protected  function consulta($tabla,$elemt,$condi){
        $consut;
        $real;
        if (isset($condi)and $condi!= "NULL"){
            @$consut= "SELECT ".$elemt." FROM ".$tabla." WHERE ".$condi."; ";
    					//echo $consut;
    					$real = $this -> conexion-> query($consut);
        }
        else {
            @$consut= "SELECT ".$elemt." FROM ".$tabla."; ";
    					$real=  $this -> conexion-> query($consut);
    	}
        return ($real);
    }
    
    //permite realizar registro dentro de la base de datos:
    protected  function insertar ($tabla,$valores){
        @$insert= "INSERT INTO ".$tabla." VALUES (".$valores.");";
			//echo $insert;
        $res=$this -> conexion-> query($insert);
        return $res;	
    }
    
    //permite eliminar registro;
   protected   function EliminarR($tabla,$valor1,$valor2){
        $resl;
        $resp;
        //se analiza si existen dos condiciones en caso tal se ejecuta ested codigo:
        if ((isset ($valor1) and isset ($valor2)) && ($valor1!= "NULL" and $valor2 !="NULL")){
            @$resl= "DELETE FROM ".$tabla." WHERE ".$valor1." AND ".$valor2."; ";
            $resp= $this -> conexion-> query($resl);
        }
        //de lo contrario se ejecuta ested apartado:
        else {
            $resl="DELETE FROM ".$tabla." WHERE ".$valor1."; ";
            $resp= $this -> conexion-> query($resl); 
        }
        return($resp);
    }
    
    //permite actualizar registro dentro de la db
    protected  function actualizar($tabla,$valor,$condi1,$condi2){
         $resl;
         $resp;
        //se analiza si existen dos condiciones en caso tal se ejecuta ested codigo:
        if ((isset ($condi1) and isset ($condi2))&&($condi1!="NULL" and $condi2!="NULL")){
            @$resl = "UPDATE ".$tabla." SET ".$valor." WHERE ".$condi1." AND ".$condi2."; ";
            //echo $resl;
            $resp = $this -> conexion-> query($resl);
        }
        //de lo contrario se ejecuta ested apartado:
        else {
            @$resl = "UPDATE ".$tabla." SET ".$valor." WHERE ".$condi1.";";
            $resp = $this -> conexion-> query($resl); 
        }
      
        return($resp);
    }
}
?>