<?php
include_once("../Vista/informes.php");
class ControlInforme extends informes{

	private $op =null;

	public function __construct(){
		$this->op=$_GET['x'];
	 	$this->InocacionInforme();
	}
	public function __destruct(){
	}
	private function InocacionInforme(){
		if (isset($this->op) ){
				switch($this->op){
					case 1:
						$this ->confirInfo(); 
						$this ->nuevaEstructura();
						$this ->CapturaProUrl();
						$this ->CapturafechProy();
					break;
					case 2:
						$this ->confirInfo();
					break;
					case 3:
						$this ->confirInfo();
					break;	
					case 4:
						//$this-> Actualizar_EliminarProyct("Actualizar");
					break;	
					case 5:
						//$this-> Actualizar_EliminarProyct("Eliminar");
					break;
					case 6:
						$this ->modalBienvenida();
					break;	
					default:
						echo'
							Error  inesperado Comuniquese con su administrador
						';
					break;
				}
		}
	}
	
}
	$ejecucion= new ControlInforme(); 
?>