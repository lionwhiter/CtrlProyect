<?php
include_once("../Control/ComunicaBD.php");
include_once("../Control/gestionDirectorios.php");
class Proyecto extends comunicacionDB{
	private $ol= null;
	private $gestion;
	public function __construct(){
		$this-> gestion = new  gestionDirectorios();
		switch($_GET['op']){
			case 1:
				$this-> RegistraProyecto();	
			break;
			case 2:
				$this-> actualizarProy();
			break;
			case 3:
				$this-> EliminarProy();
			break;
			case 4:
				$this-> gestion ->buscarDirectorio($_GET["buscar"]); 
			break;
			default:
				echo'Error Opcion no existente';
			break;
		}
	}
	public function destruct(){	 
	}
	private function RegistraProyecto(){
		$resive;
		$dir=$_GET['url'];
		//captura de datos 
		$data="NULL".
					",'".$_GET["nombre"]
					."','".$_GET["titulo"]
					."','".$_GET["estado"]
					."','".$_GET["posicion"]
					."','proyectos/".$_GET["url"]
					."', '".$_GET["nota"]
					."', '".date("j/n/y")
					."',".$_GET["visible"];

		$table = "`Proyecto`(`IdProy`,`NombreProy`,`TituloProy`,`EstadoProy`,`PosicionProy`,`UrlProy`,`NotaProy`,`TiempoR`,`VisibleProy`)";
		//llamados a funcioenes de COMINICACONDE LA BD	
		if( $this-> gestion ->buscar($dir) ){
			echo '
					<div class="alert alert-dismissible fade in" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">	
								<span aria-hidden="true">
									&times;
								</span>
							</button>
							<strong class="text-center">
								<span class="glyphicon glyphicon-comment"></span>
								Informe: Ya se encuentra Registrado un Directorio con este Nombre " El Directorio no sera Creado".
							</strong>
					</div>
			';	
		}
		else {
			$this-> gestion ->creaDirectoriosWeb($dir);
			if($_GET['php']!=""){
				$this-> gestion ->creaDirectoriosWeb($dir."/php/");
			}
			if($_GET['css']!=""){
				$this-> gestion ->creaDirectoriosWeb($dir."/css/");
			}
			if($_GET['img']!=""){
				$this-> gestion ->creaDirectoriosWeb($dir."/img/");
			}
			if($_GET['js']!=""){
				$this-> gestion ->creaDirectoriosWeb($dir."/js/");
			}
		}
		$this ->open("ProyectCtrl");
		$resive = $this ->insertar($table,$data);	
		if (isset($resive)){
			echo '
				<div class="alert alert-dismissible fade in" role="alert">
						 <button type="button" onclick="refrescarlistaProy()" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span> </button>
						 <strong class="text-center">Datos Registrados con Exito.</strong>
				</div>
			';
		}
		$this ->close("ProyectCtrl");
	}
	private function actualizarProy(){
		$resive;
		$condicion = "`IdProy`='".$_GET["condicion"]."' OR `TituloProy`='".$_GET["condicion"]."'";
		$data =	
				"`NombreProy`='".$_GET["nombre"]
				."',`TituloProy`='".$_GET["titulo"]
				."',`EstadoProy`='".$_GET["estado"]
				."',`PosicionProy`='".$_GET["posicion"]
				."',`UrlProy`='".$_GET["url"]
				."',`NotaProy`='".$_GET["nota"]
				."',`VisibleProy`='".$_GET["visible"]."'";
		$this ->open("ProyectCtrl");
		$resive = $this -> actualizar("`Proyecto`",$data,$condicion,"NULL");
		if (isset($resive)){
					echo '
						<div class="alert alert-dismissible fade in" role="alert">
								 <button type="button" onclick="refrescarlistaProy()"  class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span> </button>
								 <strong class="text-center">Datos Registrados con Exito.</strong>
						</div>
				';
				}
		$this ->close("ProyectCtrl");
	}
	private function EliminarProy(){
		$resive;
		$condicion = "`IdProy`='".$_GET["condicion"]."' OR `TituloProy`='".$_GET["condicion"]."'";
		$this ->open("ProyectCtrl");
		$resive = $this -> EliminarR("`Proyecto`",$condicion,"NULL");
		if (isset($resive)){
				echo '
					<div class="alert alert-dismissible fade in" role="alert">
							 <button type="button" onclick="refrescarlistaProy()"  class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span> </button>
							 <strong class="text-center">Datos Eliminados con exito.</strong>
					</div>
				';
				}
		$this ->close("ProyectCtrl");
	}
} 
 $CrearProyect = new Proyecto();
?>

