<?php
include_once("../Control/ComunicaBD.php");
class Operaciones extends comunicacionDB{
	private $muestra=null;
	private $muestra1;
	private $VistProyct= null;
	private $cambio;
 protected function formuIngresar(){

	 echo'
		<div class="alert alert-dismissible fade in" role="alert" id="opResult marco">
			<button type="button" onclick="cerrar()" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">	
						&times;
				</span> 
			</button>
			<h2 class="text-center texto">Registro de Proyecto</h2>
			<form  class="form" >
				<div  id="posicionUrl" class="form-group">
					<label for="Proyecto Nuevo o Existente">Descripcion de Proyecto:</label>
					<button type="button" class="close"  title="Describe si el proyecto es Nuevo o Existe">
						<span  class="descricion1" aria-hidden="true">
								?
						</span> 
					</button>
					<div id="Url" class="text-center">
						Proyecto:<a title="Creara toda la Estructura Web de un Proyecto" href="#nuevo" onclick="" class="btn  btn-log" data-toggle="modal">Nuevo</a></br>
						Proyecto:<a title="Buscara en el Directorio, un Proyecto" href="#urlProyect" onclick="" class="btn btn-log" data-toggle="modal">Existente</a>
					</div>
				</div>	
				<div class="form-group">
					<label for="Despcricion">Datos Primarios:</label>
					<input type="text" name="" id="nombre" title="nombre que se le dica a un proyecto" placeholder="Nombre" class="form-control">
					<input type="text" name="" id="titulo"  placeholder="Titulo" title="Titulo de la aplicacion" class="form-control">
				</div>
				<div  id="fecha" class="form-group">
					<label class="text-center"for="Fechas para el Proyecto">Descripcion de Fechas del Proyecto:</label>
					<button type="button" class="close"  title="Describe las Fechas del Proyectos">
						<span  class="descricion1" aria-hidden="true">
								?
						</span> 
					</button>
					<div id="fechaP" class="text-center">
						Establecer:<a title="Creara toda la Estructura Web de un Proyecto" href="#fechas" onclick="" class="btn  btn-log" data-toggle="modal">Fechas</a></br>
					</div>
				</div>
				<div class="form-group">
					<label for="secundarios">Datos Referencial:</label>
					';
		
	 				$this->etiquetas("posicion",1," ");
	 				$this->etiquetas("estado",1," ");
	 				
		echo' 
					<select title="describe si tu proyecto puede ser o no publico" class="form-control"  name="" id="visible">
						<option value="no">Visible...</option>
						<option value="true">Si</option>
						<option value="false">no</option>
				 	</select>
					<textarea name="" id="nota" cols="10" title="posible descripcion de la nota del proyecto" placeholder="Nota sobre el Proyecto" rows="2" class="form-control"></textarea>
				</div>	
					<a href="#confirInfo" onclick="validacion(1)" class="btn btn-default btn-block" data-toggle="modal">Registrar <span class="glyphicon glyphicon-floppy-disk"></span></a>
			</form>
		</div>
	';
}

 protected function formuActualizar(){
	echo'
		<div id="opResult marco" class=" alert alert-dismissible fade in" role="alert">
			<button type="button" onclick="cerrar()" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">	
						&times;
				</span> 
			</button>
			<h4 class="text-center texto">Actualizar Proyecto</h4>
			<form class="form" >
				<div class="form-group">
					<label for="Despcricion">Ingrese:</label>
					<div class="input-group">
						<div class="input-group-addon">
							<span class="glyphicon glyphicon-search"></span>
						</div>
						<input type="text" onKeyup="proyectActu(4)" name="" id="actuar" title="Recuerda no dejar espacios al principio" placeholder="Titulo,Codigo de proyecto" class="form-control">
					</div>
				</div>
			</form>
			<div id="modificar">
			</div>
		</div>
	';
}

protected function formuEliminar(){
	echo'
		<div id="opResult marco" class=" alert alert-dismissible fade in" role="alert">
			<button type="button" onclick="cerrar()" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">	
						&times;
				</span> 
			</button>
			<h4 class="text-center texto">Eliminar Proyecto</h4>
			<form class="form" >
				<div class="form-group">
					<label for="Despcricion">Ingrese:</label>
					<div class="input-group">
						<div class="input-group-addon">
							<span class="glyphicon glyphicon-search"></span>
						</div>
						<input type="text" onKeyup="proyectActu(5)" name="" id="actuar" title="Recuerda no dejar espacios al principio" placeholder="Titulo,Codigo de proyecto" class="form-control">
					</div>
				</div>
			</form>
			<div id="modificar">
			</div>
		</div>
	';
}
protected function Actualizar_EliminarProyct($text){
	
	$this-> buscarProyct();
	if($this-> VistProyct->num_rows == 0){
		echo "Datos no Existen enla Base de Datos";		
	}
	else {
		echo'
				<h4 class="text-center texto"> Datos de Proyecto Registrados</h4>
				<form action="" class="form" >
		';
		$this-> visionProyect();
		echo'
					
						<a href="#confirInfo" onclick="validacion(2)" class="btn btn-default btn-block" data-toggle="modal" id="envio">'.$text.'</a>
				</form>
		';
		}
}


protected function visionProyect(){

	while ($fila = $this-> VistProyct->fetch_assoc()){
			 echo'
				<div class="form-group">
					<label for="Despcricion">Datos Primarios:</label>
					<input type="text" name="" id="nombre"  value="'.$fila['NombreProy'].'" class="form-control">
					<input type="text" name="" id="titulo"   value="'.$fila['TituloProy'].'" class="form-control">
					<input type="text" name="" id="url"   value="'.$fila['UrlProy'].'"class="form-control">
				</div>
				<div class="form-group">
					<label for="secundarios">Datos Referencial:</label>
					<span>
					
			';

					 	$this->etiquetas("posicion",2,$fila['PosicionProy']);
			echo'
					</span>
					<span>
			';
					 	$this->etiquetas("estado",2,$fila['EstadoProy']);
			echo'
					</span>
					<input type="text" name="" id="visible"   value="'.$fila['VisibleProy'].'"class="form-control">
					<textarea name="" id="nota" cols="10"   rows="2" class="form-control">'.$fila['NotaProy'].'</textarea>
					
				</div>
	';	
	}
}
protected function buscarProyct(){

	@$data= "`TituloProy`='".$_GET['buscar']."' OR `IdProy`='".$_GET['buscar']."'";
	$this ->open("ProyectCtrl");
	$this-> VistProyct= $this->consulta("`Proyecto`","*",$data);
	$this ->close("ProyectCtrl");
}

	//funcion usada para invocar los selectores
private function etiquetas($elemento,$invocacion,$valor){
	$cambio="EtiquetasMar='".$elemento."'";
	
	$this ->open("ProyectCtrl");
	$this->muestra1=$this->consulta("`Marca`","MarcaMar",$cambio);
switch ($invocacion) {
	case 1:
		echo'
			<select class="form-control"  name="" id="'.$elemento.'">
				<option value="no">'.$elemento.'..</option>
			';
			while($fila = $this-> muestra1->fetch_assoc()){
				echo'
					<option value="'.$fila['MarcaMar'].'">
					'.$fila['MarcaMar'].'
					</option>
				';
			}
		echo'</select>';
	break;
	case 2:
		echo'
		<select class="form-control"  name="" id="'.$elemento.'">
			<option value="no">'.$elemento.'..</option>
			<option value="'.$valor.'" selected="selected">'.$valor.'</option>
		';

		while($fila = $this-> muestra1->fetch_assoc()){
			if ( $valor !== $fila ){
				echo'
					<option value="'.$fila['marca'].'">
					'.$fila['marca'].'
					</option>
				';	
			}

		}
		echo'</select>';
	break;
	default:
		echo"Error, no Contemplado en el modulo de Operaciones";
	break;
}
	
	$this->liberar($this->muestra1);
	$this->close("ProyectCtrl");
}
}
?>
