<?php
	@session_start();
	switch ($_SESSION['envio']) {
		case 1:
			include("../Control/ComunicaBD.php");
			break;
		default:
			include("./php/Control/ComunicaBD.php");
				$_SESSION['envio']= 1;	
			break;
	}
	class MuestraProyec extends comunicacionDB{
		private $estado;
		private $consulta;
		private $posicion=NULL;
		public function __construct(){
			$this ->open("ProyectCtrl");
			$this-> locacion();
			$this->close("ProyectCtrl");
		}
		public function __destruct(){
		}
		private function locacion(){
			$act;
			echo'
				<h1 class=""> 
					<strong id="ca">
						Proyectos<span class="sla">/</span>Registrados
					</strong>
				</h1>
				<ul class="nav nav-pills nav-stacked ">
				';
					for($cont=0; $cont<=2; $cont++){
							$this-> BusEstado("estado");
							switch($cont){
								case 0:
									$this->posicion="Prioridad";
									$act="active";
								break;
								case 1:
									$this->posicion="Activo";
									$act="";
								break;
								case 2:
									$this->posicion="Inactivo";
									$act="";
								break;
								default:
									echo'Error inesperado por el control de estado';
								break;
							}
					echo'
				
					<li  role="presentation" class="'.$act.' dropdown-toggle">
						<a href="#" class="toggle" data-toggle="dropdown" role="button">
							<span class="glyphicon glyphicon-bookmark"></span> '
							 .$this->posicion.' 
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu ">
					';
					while($fila = $this->estado ->fetch_assoc()){
						echo'
								<li class="">
											<a href="#" class="dropdown-header" >
												'.$fila['MarcaMar'].'<span class="caret"></span>
											</a>
						';
						
										@$text="`PosicionProy`='".$this->posicion."' AND `EstadoProy`='".$fila['MarcaMar']."'";
										$this->consulta=$this->escala($text);
						echo'
											<ul class="nav nav-pills nav-stacked">';
						while($fila1 = $this->consulta->fetch_assoc()){
							echo'
												<li>
													<span class="descricion">
														<button type="button" class="close " data-dismiss="alert">
															<a href="'.$fila1['UrlProy'].'" target="_blank"class="text-center">
															</a>
															<span aria-hidden="true">	
																	N
															</span> 
														</button>
														<p id ="Nota" >
															'.$fila1['NotaProy'].'
															</br>
															<span class="glyphicon glyphicon-file"></span>
															Codigo del Proyecto : "'.$fila1['IdProy'].'"
															</br>
															<span class="glyphicon glyphicon-time"></span>
															Registrado: '.$fila1['TiempoR'].'
															</br>
															<span class="glyphicon glyphicon-time"></span>
															Tiempo de Entrega: 00-00-00
															</br>
															<span class="glyphicon glyphicon-time"></span>
															Tiempo Restante: 00-00-00
														</p>
													</span>	
													<a href="'.$fila1['UrlProy'].'" target="_blank"class="text-center" >
														
													'.$fila1['TituloProy'].'
													</a>								
												</li>
							';
								}
							echo'	
											</ul>
									</li>
									<li class="divider"></li>
							';
					}
					echo'	
							</ul>
						</li>';
						}	
					echo'	
					</ul>
					';
				
		}
		private function escala($data){
			$resl;
			$resl=$this->consulta("`Proyecto`","UrlProy,TituloProy,NotaProy,IdProy,FechaRProy",$data);
			return $resl;
		}
		private function BusEstado($elemento){
			$cambio="EtiquetasMar='".$elemento."'";
			$this-> estado=$this->consulta("`Marca`","MarcaMar",$cambio);
		}
	}
	$intacia= new MuestraProyec();
?>