<?php
  /**
    *  Esta clase se encarga de mostrar la informacion que sera 
      +  modificada
      +eliminada
      +insertada, 
    *como metodo de 
      *verificacion
      + validacion 
    *de la informacion, como trabajo adicional se encuentra las siguientes funciones:
     +ayudad
    *
  */
  include_once("../Control/gestionDirectorios.php");
  class informes extends gestionDirectorios{

    protected function modalBienvenida(){
      echo ' 
      <div class="modal fade " tabindex="-1" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content marco">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Modal title</h4>
            </div>
            <div class="modal-body">
              <p>One fine body&hellip;</p>
              </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary">Save changes</button>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
      ';
    }

    protected function confirInfo(){
       echo ' 
      <div id="confirInfo" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Validacion de Datos a Salvar. <span class="glyphicon glyphicon-bell"></span></h4>
            </div>
            <div id ="contenidoConfirmar" class="modal-body">

            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar <span class="glyphicon glyphicon-remove-circle"></span></button>
              <button type="button" class="btn " id="BotonRegistrar">Guardar <span class="glyphicon glyphicon-ok-circle"></span></button>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
      ';
    } 
     protected function nuevaEstructura(){
       echo ' 
      <div id="nuevo" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Creacion de Nuevas Estructuras Web. <span class="glyphicon glyphicon-bell"></span></h4>
            </div>
            <div  class="modal-body">
              <form  class="form" >
								<div class="form-group ">
									<label for="CarpetaRaiz" class="form-control-label">
                    Nombre de Carpeta Raiz: 
                  </label>
									<div class="col-sm-10">	
                    <div class="input-group">
                      <div class="input-group-addon">	
                        <span class="glyphicon glyphicon-folder-open"></span>		
                      </div>						
                      <input type="text" class="form-control" id="campo1" onKeyup="validacionInterna1()" placeholder="Nombre de la Carpeta Raiz del Proyecto"> 
                    </div>
									</div>
                  <div id="notificacion">
                  </div>
            		</div>
                <div class="form-group">
                    <label for="Despcricion">Seleciona las carpetas que deseas en tu proyecto:</label>
           					<div class="checkbox">
                        <span class="glyphicon glyphicon-folder-close"></span>
												<label> 
														<input  type="checkbox" name="Carpeta" id="php" value="php">Php
												</label>
										</div>
										<div class="checkbox">
                        <span class="glyphicon glyphicon-folder-close"></span>
												<label>
													<input type="checkbox" name="Carpeta" id="css" value="css">Css 
												</label>
												
										</div>
										<div class="checkbox">
                        <span class="glyphicon glyphicon-folder-close"></span>
												<label>
													  <input type="checkbox" name="Carpeta" id="img" value="img">Img
												</label>
										</div>
										<div class="checkbox">
                        <span class="glyphicon glyphicon-folder-close"></span>
												<label>
													  <input type="checkbox" name="Carpeta" id="js" value="js">Js
												</label>
										</div>
										<label for="Nota">Nota:</label>
                    <span class="glyphicon glyphicon-exclamation-sign"></span>
                    <p class="text-center">Las Carpetas que no esten contempladas puedes crearla de manera manual.
                    </p>
                </div>
              </form>
					  </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar <span class="glyphicon glyphicon-remove-circle"></span></button>
              <button type="button" class="btn" id="nuevaEstructura" data-dismiss="modal" onclick="muestraURL()">Guardar <span class="glyphicon glyphicon-ok-circle"></span></button>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
      ';
    } 
		protected function CapturaProUrl(){
			  echo ' 
      <div id="urlProyect" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Captura de Url de Proyecto Existente. <span class="glyphicon glyphicon-bell"></span></h4>
            </div>
            <div class="modal-body">
							    <form class="form" >
                  <div class="form-group">
                    <label for="selecion de Raiz" >Seleciona la Raiz del proyecto:</label>
                    <span class="glyphicon glyphicon-folder-open"></span>
 					';
          $this-> leerProyectos();
          echo '			
                  </div>
                </form>

            </div>
            <div id="notificacion">
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar <span class="glyphicon glyphicon-remove-circle"></span></button>
              <button type="button" class="btn "  data-dismiss="modal" id="CapturaProUrl" onclick="muestraURL()">Guardar <span class="glyphicon glyphicon-ok-circle"></span></button>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
      ';
			
		}    
    protected function CapturafechProy(){
        echo ' 
      <div id="fechas" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Captura de Fechas Presente en el Proyecto . <span class="glyphicon glyphicon-bell"></span></h4>
            </div>
            <div class="modal-body">
                  
                    <span class="glyphicon glyphicon-calendar"></span>
                    <div class="hero-unit">
                        <input  type="text" placeholder="Dame Un Click"  id="tiempo" >
                    </div>
          ';
          echo '      
            </div>
            <div id="notificacion">
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar <span class="glyphicon glyphicon-remove-circle"></span></button>
              <button type="button" class="btn "  data-dismiss="modal" id="CapturaProUrl" onclick="muestraURL()">Guardar <span class="glyphicon glyphicon-ok-circle"></span></button>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
      ';
      
    }    
  }
?>