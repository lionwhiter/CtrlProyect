<?php
	@session_start();
	echo'
	<hearde class="container ">
		<nav class="navbar  navbar-default color1 navbar-fixed-top ">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" data-toggle="collase" class="collasep navbar-toggle" data-target="#X">
						<span class="sr-only">menu</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a href="" class="navbar-brand">
						Control De Proyectos.
						<strong id="ca">
							<span class="glyphicon glyphicon-home"></span>
							Abc<span class="sla">/</span>Start. 
								<span id="anonimo">ca</span>
						</strong>
					</a>
				</div>
				<div class="collase navbar-collasep" id="X">
					<ul class="nav navbar-nav navbar-right">
					
						<li class="active">
							<a href="#final">
								<span class="glyphicon glyphicon-info-sign"></span>
								Acerca
							</a>
						</li>
						<li class="dropdown ">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
								<span class="glyphicon glyphicon-tasks"></span>
								Gestion <span class="caret"></span>
							</a>
							<ul class="dropdown-menu ">
								<li onclick="llamaFormu(1)">
									<a href="#">
									 <span class="glyphicon glyphicon-paperclip"></span>
									 Ingresar Proyecto
									</a>
								</li>
								<li onclick="llamaFormu(2)">
									<a href="#">
										<span class="glyphicon glyphicon-edit"></span>
										Actualizar Proyecto
									</a>
								</li>
								<li class="divider">
								
								</li>
								<li onclick="llamaFormu(3)">
									<a href="#">
									<span class="glyphicon glyphicon-trash"></span>
									Eliminar Proyecto
									</a>
								</li>
							</ul>
						</li>
						<li class="">
							<a href="#">
								<span class="glyphicon glyphicon-list-alt"></span>
								Propuesta
							</a>
						</li>
						
						<li>
						<span class="Usuario">
							<div class="text-center marcoU">
								
	';   	/*zona de invocacion para el Usuario registrado */
	if (isset($_SESSION['usuario'])){	
		//llamado al funcion que Trae la Imagen del Usuario.
	}
	else {
		echo "Cp";
	}
	echo'
							</div>
						</span>	 
						<a href="#" class="dropdown-toggle menuUsuario" data-toggle="dropdown" role="button">
							<span class="glyphicon glyphicon-briefcase"></span>
	';
	if (isset($_SESSION['usuario'])){
		echo $_SESSION['usuario'];
	}
	else{
		echo "Usuario";
	}
	echo ' 
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu informes">
							<li >
								<a href="#">
								 <span class="glyphicon glyphicon-heart-empty"></span>
								 Perfil
								</a>
							</li>
							<li >
								<a href="#">
									<span class="glyphicon glyphicon-book"></span>
									Informes de Proyectos.
								</a>
							</li>
							<li class="divider"></li>
							<li >
								<a href="#">
								<span class="glyphicon glyphicon-cog"></span>
								Configuracion
								</a>
							</li>
	';
	if (!isset($_SESSION['usuario'])){
		echo'
							<li >
								<a href="#session">
								<span class="glyphicon glyphicon-user"></span>
								inicio de Session
								</a>
							</li>
		';
	}
	echo '
						</ul>
						</li>
					</ul>
				</div>
			</div>
		</nav>
	</hearde>
';
?>