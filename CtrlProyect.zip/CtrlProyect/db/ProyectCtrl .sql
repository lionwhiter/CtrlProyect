-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 17-10-2016 a las 03:57:47
-- Versión del servidor: 5.6.26
-- Versión de PHP: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ProyectCtrl`
--
CREATE DATABASE IF NOT EXISTS `ProyectCtrl` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ProyectCtrl`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Borrador`
--

CREATE TABLE IF NOT EXISTS `Borrador` (
  `IdBor` int(11) NOT NULL,
  `MensajeBor` varchar(200) NOT NULL,
  `FechaBor` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Configuracion`
--

CREATE TABLE IF NOT EXISTS `Configuracion` (
  `SeguimientoDeVisitante` tinyint(1) NOT NULL,
  `SeguimientoDeUsua` tinyint(1) NOT NULL,
  `Seguimiento` tinyint(1) NOT NULL,
  `Visible` tinyint(1) NOT NULL,
  `IdConf` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `CtrlProyect`
--

CREATE TABLE IF NOT EXISTS `CtrlProyect` (
  `id` int(11) NOT NULL,
  `accion` varchar(100) NOT NULL,
  `Usua` varchar(50) NOT NULL,
  `idEmp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Empresa`
--

CREATE TABLE IF NOT EXISTS `Empresa` (
  `IdEmp` int(11) NOT NULL,
  `NombreEmp` varchar(100) DEFAULT NULL,
  `DirrecionEmp` varchar(200) DEFAULT NULL,
  `CorreoEmp` varchar(50) DEFAULT NULL,
  `DedicacionEmp` varchar(500) DEFAULT NULL,
  `NumProyEmp` int(11) NOT NULL,
  `FacEmp` varchar(100) NOT NULL,
  `TwitterEmp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Marca`
--

CREATE TABLE IF NOT EXISTS `Marca` (
  `IdMar` int(11) NOT NULL,
  `EtiquetasMar` varchar(25) NOT NULL,
  `MarcaMar` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `Marca`
--

INSERT INTO `Marca` (`IdMar`, `EtiquetasMar`, `MarcaMar`) VALUES
(1, 'posicion', 'Prioridad'),
(2, 'posicion', 'Activo'),
(3, 'posicion', 'Inactivo'),
(4, 'estado', 'Produccion'),
(5, 'estado', 'Prueba'),
(6, 'estado', 'Desarrollo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Movimiento`
--

CREATE TABLE IF NOT EXISTS `Movimiento` (
  `IdMov` int(11) NOT NULL,
  `UsuMov` varchar(50) NOT NULL,
  `FechaMov` date NOT NULL,
  `MoviMov` varchar(20) NOT NULL,
  `HoraMov` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Proyecto`
--

CREATE TABLE IF NOT EXISTS `Proyecto` (
  `IdProy` int(11) NOT NULL,
  `UrlProy` varchar(500) NOT NULL,
  `NombreProy` varchar(200) NOT NULL,
  `TituloProy` varchar(200) NOT NULL,
  `NotaProy` varchar(100) NOT NULL,
  `EstadoProy` varchar(50) NOT NULL,
  `PosicionProy` varchar(50) NOT NULL,
  `tagsProy` int(11) NOT NULL,
  `FechaRProy` date NOT NULL,
  `FechaEProy` date NOT NULL,
  `VisibleProy` tinyint(1) NOT NULL,
  `PropuestaProy` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Trabajo`
--

CREATE TABLE IF NOT EXISTS `Trabajo` (
  `IdTra` int(11) NOT NULL,
  `VisualizadoTra` varchar(200) NOT NULL,
  `HoraETra` time NOT NULL,
  `HoraSTra` time NOT NULL,
  `FechaTra` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuario`
--

CREATE TABLE IF NOT EXISTS `Usuario` (
  `IdUsu` int(11) NOT NULL,
  `NombreUsu` varchar(50) NOT NULL,
  `ApellidoUsu` varchar(50) NOT NULL,
  `UsuarioUsu` varchar(50) DEFAULT NULL,
  `Clave` varchar(20) DEFAULT NULL,
  `Cargo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Borrador`
--
ALTER TABLE `Borrador`
  ADD PRIMARY KEY (`IdBor`);

--
-- Indices de la tabla `Configuracion`
--
ALTER TABLE `Configuracion`
  ADD PRIMARY KEY (`IdConf`);

--
-- Indices de la tabla `CtrlProyect`
--
ALTER TABLE `CtrlProyect`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `Empresa`
--
ALTER TABLE `Empresa`
  ADD PRIMARY KEY (`IdEmp`);

--
-- Indices de la tabla `Marca`
--
ALTER TABLE `Marca`
  ADD PRIMARY KEY (`IdMar`);

--
-- Indices de la tabla `Movimiento`
--
ALTER TABLE `Movimiento`
  ADD PRIMARY KEY (`IdMov`);

--
-- Indices de la tabla `Proyecto`
--
ALTER TABLE `Proyecto`
  ADD PRIMARY KEY (`IdProy`);

--
-- Indices de la tabla `Trabajo`
--
ALTER TABLE `Trabajo`
  ADD PRIMARY KEY (`IdTra`);

--
-- Indices de la tabla `Usuario`
--
ALTER TABLE `Usuario`
  ADD PRIMARY KEY (`IdUsu`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Borrador`
--
ALTER TABLE `Borrador`
  MODIFY `IdBor` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `Configuracion`
--
ALTER TABLE `Configuracion`
  MODIFY `IdConf` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `CtrlProyect`
--
ALTER TABLE `CtrlProyect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `Empresa`
--
ALTER TABLE `Empresa`
  MODIFY `IdEmp` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `Marca`
--
ALTER TABLE `Marca`
  MODIFY `IdMar` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `Proyecto`
--
ALTER TABLE `Proyecto`
  MODIFY `IdProy` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `Trabajo`
--
ALTER TABLE `Trabajo`
  MODIFY `IdTra` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `Usuario`
--
ALTER TABLE `Usuario`
  MODIFY `IdUsu` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
