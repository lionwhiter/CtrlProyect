
$(document).ready(function(){
 	/*	$(function () {
        $( "" ).dialog({
             autoOpen: false,
             show: {
             effect: "blind",
             duration: 100
             },
             hide: {
             effect: "explode",
             duration: 1000
             }
		$("").click(function(){
		$("").dialog("open");	 
*/
});
//funcion general de llamado AJAX
function llamadoR(METHO,DIR,DATA,OBJ){
	console.log("OperacionAJAX:<-iniciada->");//mensaje a la consola 
	console.log("OperacionAJAX:<-enProceso->");//mensaje a la consola 
	$.ajax({
		type: METHO,
		url: DIR,
		data: DATA,
		datatype:"JSON",
		cache: false,
		success: function(resp){
			OBJ.addClass("marco");
			OBJ.html(resp);
		}
	});
	console.log("OperacionAJAX:<-Finalizada->");//mensaje a la consola 
}
function llamado(METHO,DIR,DATA,OBJ){
		console.log("OperacionAJAX:<-iniciada->");//mensaje a la consola 
		console.log("OperacionAJAX:<-enProceso->");//mensaje a la consola 
		$.ajax({
			type: METHO,
			url: DIR,
			data: DATA,
			datatype:"JSON",
			cache: false,
			success: function(resp){
				OBJ.html(resp);
			}
		});
	console.log("OperacionAJAX:<-Finalizada->");//mensaje a la consola
}