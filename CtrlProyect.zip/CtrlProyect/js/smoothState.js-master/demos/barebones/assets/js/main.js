$(function() {
  'use strict';
  $('#main').smoothState({ debug: true });
});
