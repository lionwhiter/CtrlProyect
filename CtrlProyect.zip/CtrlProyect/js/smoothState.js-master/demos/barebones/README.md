# Demo: Default features of smoothState.js

This demo shows the basic features of [smoothState.js](https://github.com/miguel-perez/smoothState.js).

You can [view the demo here](https://rawgit.com/miguel-perez/smoothState.js/master/demos/barebones/index.html).