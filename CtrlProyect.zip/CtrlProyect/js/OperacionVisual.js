//funcion de resfrescamiento de lista de proyectos registrado 
function refrescarlistaProy(){
	var SenoraM=$("#MustraProy");
	var Senora=$("#puntoRefe");
	var datastring= {
					"Resf" : "si"
				}
	SenoraM.html('<div class="text-center"><img src="../img/load.gif"/></div>');
	llamado("GET","./php/Vista/MuestraProyec.php",datastring,SenoraM);
	cerrar();
}
function cerrar(){
	$("#Operacion").removeClass("marco");
}
//funcion de llamado los forrmulario y informacion de confirmacion[O.O]
//                                                               [__!__]
function llamaFormu(dato){	
		var op= $("#Operacion");
		var opConfirmar= $("#confimar");
		var datastring= 'x=' +dato;
		op.removeClass("marco");
		op.html('<div class="text-center"><img src="../img/load.gif"/></div>');
		llamadoR("GET","./php/Control/operacion.php",datastring,op);
		llamadoR("GET","./php/Control/ControlInforme.php",datastring,opConfirmar);	
}
//funcion encargada de la muestra de la URL 
function muestraURL(){
	var op=$("#posicionUrl");	
	var url1=$("#campo1").val();
	var url2=$("#proyectos2").val();
	if (url1 != "undefined" && url2 == "no" ){
		var mensaje='<label for="CarpetaRaiz" class="form-control-label">'+
					'Nombre del Directorio Raiz:</label><input type="text" id="url"'+
					'title="Enlace en el que se encontrar el proyecto" value="'+
					url1
					+'"class="form-control" disabled="disabled">';	
	}
	else{
		var mensaje='<label for="CarpetaRaiz" class="form-control-label">'+
					'Nombre del Directorio Raiz:</label><input type="text" id="url"'+
					'title="Enlace en el que se encontrar el proyecto" value="'+
					url2
					+'"class="form-control" disabled="disabled">';	
	}
	op.html(mensaje);
}
/*
	estad funcion se encuentra desarrollada para la 
	validacion internat de las carpetas que se eligue para crear 
	y validar si existen.
	se encuentra con algunos errores logicos que tienen que se correguido 
	Error de accesibilidad, se tiene que dar muchos click para acceder a 
	a la captura de una carpeta.
*/
function  validacionInterna1(){
	var cont = 0;
	var mostraMod = $("#notificacion");
	var valor = $("#campo1").val();
	var datastring ={
				"op":4,
				"buscar": valor
			}
	var mensaje	= 	'<div class="alert alert-dismissible fade in" role="alert">'+
					'<button type="button"  class="close" data-dismiss="alert" aria-label="Close">'+	
					'<span aria-hidden="true">'+
					'&times;'+
					'</span>'+
					'</button>'+
					'<strong class="text-center">'+
					'<span class="glyphicon glyphicon-fire"></span>'+
					'Ested Campo no puede Quedar Vacio O con Espacios.'+
					'</strong></div>';
	console.info("Recolecion de Datos Realizada");
	if (valor.length !=0 && valor.substring(0,1)==" "){
		mostraMod.html(mensaje);
		cont++;
	}
	if (valor.length <= 0){
		mostraMod.html(mensaje);
		cont++;
	}
	if (cont<=0){
		llamado("GET","./php/Modelo/Proyect.php",datastring,mostraMod);
	}
	console.log("final de la Funcion");
}
function validacion(op){
	var cont = $("#contenidoConfirmar");
	var bt = $("#BotonRegistrar");
	var prueba= $("#envio").html();
	var datastring=null;
	var valores ="";
	var operacion,mensaje;
	
	if ( $("#Url").length ){		
		datastring="<h2 class='text-center'><span class='glyphicon glyphicon-fire'></span>Lo Sentimos..Datos Mal Formulado.</h2><span><p>"+
					"Debes Especificar si el Proyecto es:''Nuevo o Existen''</p>"+
					"</span>";
		cont.html(datastring);
	}
	else{
		valores= valores+analisis($("#nombre").val(),"nombre");
		valores= valores+analisis($("#titulo").val(),"titulo");
		valores= valores+analisis($("#url").val(),"url");
		valores= valores+analisis($("#estado").val(),"estado");
		valores= valores+analisis($("#posicion").val(),"posicion");
		valores= valores+analisis($("#visible").val(),"visible");
		switch(op){
			case 1:		
				operacion="proyectRegis()";
				mensaje="<h2>Datos validados correctamente.</h2>"+
						"<p>Puede pisar sobre Guardar.</p>";	
			break;
			case 2:
				operacion="proyect()";
				if( prueba == "Actualizar" ){
					mensaje="<h2 class='text-center'>Datos validados correctamente, para Actualizar.</h2>"+
							"<p>Puede pisar sobre Guardar.</p>";
				}
				else{
					mensaje='<h2 class="text-center">Si deseas Eliminar el proyecto: "'+
							$("#titulo").val()+'"</h2>'+
							"<p>Puede pisar sobre Eliminar.</p>";
					bt.html("Eliminar");		
				}
			break;
			default:
				alert("Error de invocacion");
			break;
		}
		if(valores.length > 1){
			datastring="<h2 class='text-center'><span class='glyphicon glyphicon-fire'></span>Error.. Datos Mal Formulado.</h2><span><p>"+
						"los siguientes Campos no pueden estar vacios.</p><p>'"+
						valores
						+"'</p></span>";
			cont.html(datastring);
		}
		else{
			cont.html(mensaje);
			bt.attr("onclick",operacion);
			bt.attr("data-dismiss","modal");
		}
	}
}

function analisis(data,name){
	var result=" ";
	if (data.length == 0){
		return(name+",");
	}
	else if(data == "no"){
		return (name+",");
	}
	else{
		return("");
	}

}
function proyectRegis(){ 
var datastring= {
									"op":1,
									"nombre":$("#nombre").val(),
									"titulo":$("#titulo").val(),
									"url":$("#url").val(),
									"nota":$("#nota").val(),	
									"estado":$("#estado").val(),
									"posicion":$("#posicion").val(),
									"visible":$("#visible").val(),
									"php":$("#php").val(),
									"css":$("#css").val(),
									"img":$("#img").val(),
									"js":$("#js").val()

								}
llamadoR("GET","./php/Modelo/Proyect.php",datastring,$("#Operacion"));
}
function proyectActu(ope){
	var mostraMod= $("#modificar");
	var valor= $("#actuar").val();
	
	if(valor.length !=0 && (valor.substring(0,1)!= " ")){
		mostraMod.html(" ");
		var datastring ={
						"x":ope,
						"buscar": valor
					}
		llamado("GET","./php/Control/operacion.php",datastring,mostraMod);	
		mostraMod.removeClass("marco");
	}
	else {
		mostraMod.html(" ");
	}		
}
function proyect(){
	var prueba= $("#envio").html();
	var datastring = null;
	if( prueba == "Actualizar" ){
		 datastring= {
									"op":2,
									"condicion":$("#actuar").val(),
									"nombre":$("#nombre").val(),
									"titulo":$("#titulo").val(),
									"url":$("#url").val(),
									"nota":$("#nota").val(),	
									"estado":$("#estado").val(),
									"posicion":$("#posicion").val(),
									"visible":$("#visible").val()
								}
	}
	else{
		 datastring= {
									"op":3,
									"condicion":$("#actuar").val(),
									"nombre":$("#nombre").val(),
									"titulo":$("#titulo").val(),
									"url":$("#url").val(),
									"nota":$("#nota").val(),	
									"estado":$("#estado").val(),
									"posicion":$("#posicion").val(),
									"visible":$("#visible").val()
								}
	}
	llamado("GET","./php/Modelo/Proyect.php",datastring,$("#Operacion"));
}
