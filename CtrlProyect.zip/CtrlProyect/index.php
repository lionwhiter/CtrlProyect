<?php 
	session_start();
	$_SESSION['envio']= 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>ControlProyect</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link type="image/png" href="./Favicon.png" rel="icon">
	<link rel="stylesheet" href="./css/normalize.css">
	<link rel="stylesheet" href="./css/bootstrap336base/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./css/jqueryuistructuremin.css">
	<link   rel="stylesheet" href="./css/index.css">
</head>
<body>	
	<?php include_once"./php/Vista/header.php";?>
	<div class="container">	
		<section class="row" id="formato">
			<div class="  col-xs-12  col-sm-12 col-md-4 " id="puntoRefe">
				<div id="MustraProy">
					<?php include("./php/Vista/MuestraProyec.php");?>	
				</div>
			</div>
			<div class="col-xs-12  col-sm-12 col-md-4 scrollflow -slide-left -opacity">
				<figure >
					<img id="imagen" src="CtrlProyect.png"/>
				</figure>
			</div>
			<div id="Operacion" class="col-xs-12 col-sm-12 col-md-4">
				
			</div>
			<span id="confimar">
				
			</span>
		</section>
		<section id="final">
		<div class="container">
			<div class="row  scrollflow -pop -opacity" id="session">
				<div class="col-md-12 col-sm-12 col-xs-12 text-center marcoF ActFooter">
					<ul class="list-inline ">
						<li class="">
						
							<h3 class="">
								Inicio<span class="glyphicon glyphicon-user"></span> 
							</h3>
						</li>
						<li class="">
							<h3>
								Comunicacion<span class="glyphicon glyphicon-comment"></span> 
							</h3>
						</li>
						<li class="">
							<h3>
								Donacion<span class="glyphicon glyphicon-shopping-cart"></span> 
							</h3>
						</li>
						<li class="">
							<h3>
								Descripcion<span class="glyphicon glyphicon-flag"></span> 
							</h3>
						</li>
					</ul>
     			</div>
     			<!-- Zona que Permite mostar informacion Sobre la Lincencia del Proyecto-->
	     		<div class="col-md-4 col-sm-12 col-xs-12 marcoF">
	     			<div class="list-inline ">
							<a href="#" class="list-group-item ActFooter scrollflow -slide-right -opacity">
									<h4 class="list-group-item-heading text-center">
										<img  class="fimg"src="./img/cc_licencias.png" alt="lincencia" title="licencia">
									</h4>
									<p class="list-group-item-text">
											Lincencia;(CC BY-NC-SA)	
									</p>
							</a>
							<a href="#" class="list-group-item">
									<h4 class="list-group-item-heading text-center scrollflow -slide-right -opacity">
										<img  class="fimg" src="./img/cc1.png" alt="">
									</h4>
									<p class="list-group-item-text">
										Proivido el uso comercial 
									</p>
									<p class="text-center">
										Estad aplicacion esta consebidad para que se usada de manera no cormelcial
										estad aplicacion solo resive donaciones para su mantenimiento a su Creador.
									</p>
							</a>
							<a href="#" class="list-group-item">
									<h4 class="list-group-item-heading text-center scrollflow -slide-right -opacity">
										<img class="fimg" src="./img/cc2.png" alt="">
									</h4>
									<p class="list-group-item-text">
									
									</p>
									<p  class="text-center">
										EL codigo tiene tiene las siguientes libertades de uso, puedes copiarlo, estudiarlo,
										modificarlo, distribuirlo.
									</p>
							</a>
							<a href="#" class="list-group-item">
									<h4 class="list-group-item-heading text-center scrollflow -slide-right -opacity">
										<img class="fimg" src="./img/cc3.png" alt="">
									</h4>
									<p class="list-group-item-text">
										CtrlProyect es un proyecto de ayudad y gestion el cual fue creado para la ayuda a otros programadores, si deseas realizar cualquier modificacion comunicate primero con el autor "Alonso Blanco".
									</p>
							</a>
    				</div>	
	     		</div>
	     		<!-- Contendor del Formulario de inicio de Seccion-->
				<div class="col-md-4 col-sm-12 col-xs-12 marcoF " >
					<div class="inicio" >				
				  	    <form class="form " action="" method="POST" enctype="multipart/form-data" role="form">
					        <div class="form-group">
					            <label  class="scrollflow -slide-right " for="Usuario">Usuario</label>
					            </br>
					            <input type="text" class="form-control " id="Usuario" placeholder="Alonso Blanco">
					        </div>
					        <div class="form-group">
					            <label class="scrollflow -slide-right " for="Clave"> Constraseña</label>
					            <input type="password" class="form-control  " id="clave" 
					            placeholder="Ej:Alfonzo Leon">
					       </div>
					       
					       <button type="submit" class="btn btn-default btn-block scrollflow -slide-right ">Iniciar</button>
					    </form>
					</div>
					<h3 class="inicio text-center"> Como Dialogar Con los Desarrolladores</h3>
						<p class="inicio">
							YolbysAlonso94@gmail.com				    	 
				    	</p>
				    <p class="inicio">
				    	Ut enim ad minim veniam,
				    	quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				    	consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				    	cillum dolore eu fugiat nulla pariatur.
				    </p>
				    <p class="inicio">
				    	 Excepteur sint occaecat cupidatat non
				    	proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				    </p>
				</div>
				<!--Informacion sobre la Comunicacion y Donaciones al Proyecto.-->
				<div class="col-md-4 col-sm-12 col-xs-12 marcoF">
				</div>
			</div>
		</div>
		</section>
	</div>
	<footer>
		<p> 
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		</p>
	</footer>
	<script src="js/jquerymin.js"></script>
	<script src="js/bootstrap336base/bootstrap.min.js"></script>
	<script src="js/jqueryui/jquery-ui.min.js"></script>
	<script src="js/eskju.jquery.scrollflow.min.js"></script>
	<script src="js/myjquery.js"></script>
	<script src="js/OperacionVisual.js"></script>	
	<script type="text/javascript">
        // When the document is ready
        $(document).ready(function () {
            
            $('#tiempo').datepicker({
                format: "dd/mm/yyyy"
            });  
        
        });
    </script>
</body>
</html>
      

 

   
